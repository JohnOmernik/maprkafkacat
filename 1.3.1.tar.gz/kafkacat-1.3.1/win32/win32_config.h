#pragma once

#define KAFKACAT_VERSION "1.3.0-dev" /* Manually updated */